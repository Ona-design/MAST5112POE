import { useState } from 'react';
import {
  FlatList,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

const COURSES = ['Starters', 'Main', 'Desserts'];

export default function Index() {
  const [menuItems, setMenuItems] = useState([]);
  const [currentScreen, setCurrentScreen] = useState('home');
  const [dishName, setDishName] = useState('');
  const [dishDescription, setDishDescription] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState('Main');
  const [errorMessage, setErrorMessage] = useState('');

  const resetForm = () => {
    setDishName('');
    setDishDescription('');
    setPrice('');
    setCourse('Main');
    setErrorMessage('');
  };

  const handleSaveDish = () => {
    if (!dishName.trim()) {
      setErrorMessage('enter dish name');
      return;
    }
    if (!dishDescription.trim()) {
      setErrorMessage('enter a description');
      return;
    }
    if (!price.trim()) {
      setErrorMessage('enter a price');
      return;
    }
    const numericPrice = Number(price);
    if (isNaN(numericPrice) || numericPrice <= 0) {
      setErrorMessage('enter a number above 0');
      return;
    }
    const newDish = {
      id: Date.now().toString(),
      dishname: dishName.trim(),
      dishDescription: dishDescription.trim(),
      course,
      price: numericPrice,
    };
    setMenuItems((prevItems) => [...prevItems, newDish]);
    resetForm();
    setCurrentScreen('home');
  };

  const renderMenuItem = ({ item }) => (
    <View style={styles.dishRow}>
      <View style={styles.dishInfo}>
        <Text style={styles.dishName}>{item.dishname}</Text>
        <Text style={styles.dishPrice}>R {item.price.toFixed(2)}</Text>
      </View>
      <View style={styles.dishActions}>
        <View style={[styles.pillButton, styles.editPill]}>
          <Text style={styles.pillText}>EDIT</Text>
        </View>
        <View style={[styles.pillButton, styles.deletePill]}>
          <Text style={styles.pillText}>DELETE</Text>
        </View>
      </View>
    </View>
  );

  const renderHomeScreen = () => (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>CURRENT MENU</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setCurrentScreen('add')}
        >
          <Text style={styles.addButtonText}>ADD NEW DISH</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.filterBox}>
        <Text style={styles.filterText}>COURSE ▾</Text>
      </View>

      <Text style={styles.subtitle}>Main Menu List</Text>

      {menuItems.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}></Text>
        </View>
      ) : (
        <FlatList
          data={menuItems}
          keyExtractor={(item) => item.id}
          renderItem={renderMenuItem}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </View>
  );

  const renderAddScreen = () => (
    <View style={styles.container}>
      <Text style={styles.addScreenTitle}>ADD NEW DISH</Text>

      <Text style={styles.label}>Dish Name</Text><TextInput
 style={styles.input}
 value={dishName}
        onChangeText={setDishName}
      />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.textArea]}
        value={dishDescription}
        onChangeText={setDishDescription}
        multiline
        numberOfLines={4}
      />

      <View style={styles.row}>
        <View style={styles.halfField}>
          <Text style={styles.label}>Price</Text>
          <TextInput
            style={styles.input}
            value={price}
            onChangeText={setPrice}
            keyboardType="numeric"
          />
        </View>
        <View style={styles.halfField}>
          <Text style={styles.label}>Course</Text>
          <View style={styles.courseColumn}>
            {COURSES.map((c) => (
              <TouchableOpacity
                key={c}
                style={[
                  styles.courseOption,
                  course === c && styles.courseOptionSelected,
                ]}
                onPress={() => setCourse(c)}
              >
                <Text
                  style={[
     styles.courseOptionText,
                    course === c && styles.courseOptionTextSelected,
                  ]}
                >
                  {c}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      {errorMessage ? (
        <Text style={styles.errorText}>{errorMessage}</Text>
      ) : null}

      <View style={styles.row}>
        <TouchableOpacity
          style={[styles.secondaryButton, styles.halfField]}
          onPress={() => {
            resetForm();
            setCurrentScreen('home');
          }}
        >
          <Text style={styles.secondaryButtonText}>CANCEL</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.saveButton, styles.halfField]}
          onPress={handleSaveDish}
        >
          <Text style={styles.primaryButtonText}>SAVE CHANGES</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" />
      {currentScreen === 'home' ? renderHomeScreen() : renderAddScreen()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FAF7F2' },
  container: { flex: 1, paddingHorizontal: 20, paddingTop: 20 },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: { fontSize: 20, fontWeight: '700', color: '#2E2A26' },
  addScreenTitle: {
    fontSize: 22,
    fontWeight: '600',
    fontStyle: 'italic',
    color: '#2E2A26',
    marginBottom: 8,
  },
  subtitle: { fontSize: 15, fontWeight: '600', color: '#2E2A26', marginTop: 16, marginBottom: 8 },
  addButton: {
    backgroundColor: '#C1440E',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
  },
  addButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 12 },
  filterBox: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#D8CFC4',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    alignSelf: 'flex-start',
  },
  filterText: { fontSize: 14, color: '#2E2A26' },
  label: { fontSize: 14, fontWeight: '600', color: '#2E2A26', marginTop: 12, marginBottom: 6 },
  input: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#D8CFC4',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
  },
  textArea: { height: 90, textAlignVertical: 'top' },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  halfField: { width: '48%' },
  courseColumn: { gap: 6 },
  courseOption: {
    paddingVertical: 8,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#D8CFC4',
    alignItems: 'center',
  },
  courseOptionSelected: { backgroundColor: '#C1440E', borderColor: '#C1440E' },
  courseOptionText: { color: '#2E2A26', fontWeight: '600', fontSize: 13 },
  courseOptionTextSelected: { color: '#FFFFFF' },
  errorText: { color: '#B3261E', marginTop: 14, fontSize: 14, fontWeight: '500' },
  primaryButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 },
  saveButton: {
    backgroundColor: '#2E7D32',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  secondaryButton: { backgroundColor: '#EDE7DE', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginTop: 20 },
  secondaryButtonText: { color: '#2E2A26', fontWeight: '700', fontSize: 14 },
  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 30 },
  emptyStateText: { textAlign: 'center', color: '#8A8074', fontSize: 15 },
  dishRow: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#EDE7DE',
  },
  dishInfo: { marginBottom: 8 },
  dishName: { fontSize: 15, fontWeight: '700', color: '#2E2A26' },
  dishPrice: { fontSize: 13, color: '#6B6259', marginTop: 2 },
  dishActions: { flexDirection: 'row', gap: 8 },
  pillButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    borderWidth: 1,
  },
  editPill: { borderColor: '#2E7D32' },
  deletePill: { borderColor: '#B3261E' },
  pillText: { fontSize: 11, fontWeight: '700', color: '#2E2A26' },
});